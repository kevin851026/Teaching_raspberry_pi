content=`cat /sys/class/net/wlan0/address`
id=`grep "$content" ./id_list.txt | cut -d , -f 2`
raspistill -vf -o /home/pi/rasp/photo/"$id"_photo_$(date +"%Y%m%d_%H%M%S").jpg
